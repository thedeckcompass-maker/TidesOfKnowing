# Daughter or PA Posting Instructions

**Week:** 02 - 2026-06-08 to 2026-06-14

**Source:** TOK-0202 - About Leigh Spencer

**Pack type:** About Introduction Pack (first social introduction week)

**Pack size:** 17 assets (16 introduction + 1 soft training invitation)

**Source URL:** https://www.tidesofknowing.com/about/

---

## Start here

1. Open `START_HERE_FOR_POSTING.html` in your browser. This is the main working interface.

2. Use the top navigation bar to reach Home, Weekly Pack Builder, Usage Ledger, Image Slots, Scheduler CSV or these instructions.

3. Read the week-at-a-glance table. Check Visual Strategy, Visual Source, Image Creation Needed, Business Objective, CTA Type and Required Before Posting.

4. Use Copy Post buttons to copy caption and post text. Do not open Markdown files unless Leigh asks you to.

5. Markdown files in this folder are backup and source records only.

---

## First-introduction week

This is the first Tides of Knowing social posting week across all platforms. The About page introduces Leigh Spencer and the platform to a cold audience.

* Person and platform come before method and product
* Every post should make sense to someone who has never heard of Tides of Knowing
* Only one softened training invitation (Sunday 6:30 p.m. Instagram)
* Former Monday and Wednesday training slots are now introduction posts

---

## Image source vs created image

* **If Image Creation Needed is No:** optional page image if the scheduler asks for upload. No file required in `images/` unless the scheduler requires a local copy.

* **If Image Creation Needed is Yes:** do not post until the image exists in `images/`.

* **Use the exact Expected Image Filename** shown on the posting page and in `SCHEDULER_EXPORT.csv`.

* **Do not create or substitute images** without Leigh's approval.

Image creation briefs are in `IMAGE_CREATION_BRIEFS.md` and inside each post dropdown.

---

## How many posts this week?

This week has **17 assets** across **7 days**. Some days have **two or three posts** on different platforms.

| Day | Posts |
| :--- | :--- |
| Monday 2026-06-08 | X / Twitter thesis (9:00) + X / Twitter who Leigh (10:30) + Facebook (12:30) |
| Tuesday 2026-06-09 | X / Twitter + Instagram carousel |
| Wednesday 2026-06-10 | X / Twitter + Facebook (7:30 p.m.) + Pinterest (8:30 p.m.) |
| Thursday 2026-06-11 | X / Twitter + Facebook |
| Friday 2026-06-12 | X / Twitter thread + Instagram quote |
| Saturday 2026-06-13 | Substack + Pinterest |
| Sunday 2026-06-14 | X / Twitter + Instagram soft training (6:30) + Facebook (7:30) |

---

## Posting rules

* Post or schedule only items marked **Ready** in the HTML interface.

* Do **not** post items where **Image Creation Needed is Yes** until Leigh supplies the image in `images/`.

* Copy text using the **Copy Post** button. Copy exactly unless Leigh says otherwise.

* Do not alter captions, links, hashtags or CTAs without Leigh's permission.

* The single training invitation links to the About page as the bridge destination.

---

## X / Twitter thread (Friday)

Asset: `2026-06-12_x-twitter_TOK-0202_thread-01_ready.md`

Post Tweet 1/6 first, then reply in order through Tweet 6/6. Do not post as separate unlinked tweets.

---

## Instagram carousel (Tuesday)

Upload slides in order (slide-01 through slide-06). Link in bio to About page.

---

## Pinterest

Link every pin to: https://www.tidesofknowing.com/about/

---

## Substack

Post as a Substack note on Saturday 9:30 a.m.

---

## After posting

Log posts in the scheduler or Leigh's tracking sheet as directed. Report any platform errors to Leigh.

---

## Files in this folder

| File | Purpose |
| :--- | :--- |
| START_HERE_FOR_POSTING.html | Main posting interface |
| SCHEDULER_EXPORT.csv | Scheduler import |
| IMAGE_CREATION_BRIEFS.md | Image briefs for Leigh or designer |
| images/IMAGE_SLOTS.md | Image slot tracker |
| DAUGHTER_POSTING_INSTRUCTIONS.md | This file |
