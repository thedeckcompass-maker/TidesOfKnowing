# Weekly Social Asset

* **Source ID:** TOK-0013
* **Source title:** Rethinking Timing
* **Source URL:** https://www.tidesofknowing.com/articles/rethinking-timing/
* **Platform:** Instagram
* **Posting date:** 2026-06-25 (Thursday)
* **Scheduled time:** 6:30 p.m.
* **Asset type:** Deck Compass training invitation
* **Status:** ready-after-link-added
* **Asset headline:** Continue the practice inside The Deck Compass
* **Business objective:** Training invitation
* **CTA type:** Deck Compass training invitation

## Post copy

CAPTION:

The shift from more content to better perception does not happen by accumulation alone. It happens through trained symbolic discernment.

If this week's work on timing, readiness and thresholds resonated, The Deck Compass training is the continuing pathway to practise that kind of reading with structure.

Learn to strengthen this kind of symbolic discernment:
Link in bio when available: [DECK_COMPASS_TRAINING_URL_REQUIRED]

#SymbolicLiteracy #TarotMethodology #ReflectivePractice #TheDeckCompass #TidesOfKnowing

## CTA

Explore The Deck Compass training

## Visual Strategy

Needs quote card

## Visual Source

Text-based design

## Image Creation Needed

Yes

## Expected Image Filename

images/2026-06-25_instagram_TOK-0013_deck-compass-training-01.png

## Image Folder

images/

## Required Before Posting

Yes (image and training URL required before posting)

## Image Creation Brief

**Purpose:** Training invitation quote card bridging from timing/threshold theme to Deck Compass practice.

**Platform:** Instagram

**Aspect ratio:** 4:5

**Visual concept:** Simple invitation card. Cream background, deep blue type, teal accent. Compass or threshold motif, subtle.

**Required elements:** No urgency bait. No pricing or cohort claims. Calm authority.

**Text overlay:** Better perception, not more content. / Practise symbolic discernment inside The Deck Compass.

**Style direction:** Elegant, grounded, spacious. Commercial without salesy tone.

**Brand constraints:** Tides of Knowing palette. No generic course marketing aesthetic.

**Alt text draft:** Instagram training invitation card from Tides of Knowing on practising symbolic discernment through The Deck Compass.

**Expected filename:** images/2026-06-25_instagram_TOK-0013_deck-compass-training-01.png

**Image folder:** images/

## Posting instructions for daughter or PA

Do not post until image exists in images/ AND Leigh replaces [DECK_COMPASS_TRAINING_URL_REQUIRED] with live training URL in caption and bio link. Post on Thursday 2026-06-25 at 6:30 p.m.

## Notes

Week D training invitation. Thursday Instagram slot. Status ready-after-link-added.
