# Weekly Social Asset

* **Source ID:** TOK-0013
* **Source title:** Rethinking Timing
* **Source URL:** https://www.tidesofknowing.com/articles/rethinking-timing/
* **Platform:** X / Twitter
* **Posting date:** 2026-06-28 (Sunday)
* **Scheduled time:** 9:00 a.m.
* **Asset type:** Deck Compass training invitation
* **Status:** ready-after-link-added
* **Asset headline:** Practise conditional timing with structure
* **Business objective:** Training invitation
* **CTA type:** Deck Compass training invitation

## Post copy

Conditional timing reads readiness, not dates. That discipline is practised, not collected.

Continue the practice through The Deck Compass training:
[DECK_COMPASS_TRAINING_URL_REQUIRED]

#TrainedPerception #SymbolicLiteracy #TheDeckCompass #TidesOfKnowing

## CTA

Continue the practice through The Deck Compass training

## Visual Strategy

Optional visual, article image preferred

## Visual Source

Article feature image

## Image Creation Needed

No

## Expected Image Filename

Article feature image from source URL (no pack slot)

## Image Folder

Not required for posting

## Required Before Posting

Yes (training URL must be added before posting)

## Image source instructions

Article feature image optional.

## Image Creation Brief

Not applicable

## Posting instructions for daughter or PA

Do not post until Leigh replaces [DECK_COMPASS_TRAINING_URL_REQUIRED] with the live training URL. Post on Sunday 2026-06-28 at 9:00 a.m. Note: source-led X reflective post is also scheduled at 9:00 a.m. Stagger posts or follow Leigh's direction. Copy text exactly once URL is added.

## Notes

Week D training invitation. Sunday X / Twitter slot. Status ready-after-link-added.
