# Weekly Social Asset

* **Source ID:** TOK-0013
* **Source title:** Rethinking Timing
* **Source URL:** https://www.tidesofknowing.com/articles/rethinking-timing/
* **Platform:** Facebook
* **Posting date:** 2026-06-22 (Monday)
* **Scheduled time:** 12:30 p.m.
* **Asset type:** Deck Compass training invitation
* **Status:** ready-after-link-added
* **Asset headline:** Train discernment, not accumulation
* **Business objective:** Training invitation
* **CTA type:** Deck Compass training invitation

## Post copy

This week's article asks a hard question about tarot timing: are we reading conditions, or pretending to read dates?

The shift from more content to better perception does not happen by collecting more interpretations. It happens through trained symbolic discernment, clearer pattern recognition and reflective practice that holds up in live readings.

The Deck Compass is the continuing practice environment for readers who want to stay with this work over time. It is where the COMPASS Method becomes practised, not just understood.

Explore The Deck Compass training:
[DECK_COMPASS_TRAINING_URL_REQUIRED]

## CTA

Explore The Deck Compass training

## Visual Strategy

Use article image

## Visual Source

Article feature image

## Image Creation Needed

No

## Expected Image Filename

Article feature image from source URL (no pack slot)

## Image Folder

Not required for posting

## Required Before Posting

Yes (training URL must be added before posting)

## Image source instructions

Use article feature image when scheduler requires upload.

## Image Creation Brief

Not applicable

## Posting instructions for daughter or PA

Do not post until Leigh replaces [DECK_COMPASS_TRAINING_URL_REQUIRED] with the live training URL. Post on Monday 2026-06-22 at 12:30 p.m. Note: source-led Facebook reflective post is also scheduled at 12:30 p.m. Stagger posts or follow Leigh's direction. Copy text exactly once URL is added.

## Notes

Week D training invitation. Monday Facebook slot. Status ready-after-link-added until training URL supplied.
